import { GoogleGenAI, Type } from "@google/genai";
import { StallConfig, DesignResult, BudgetTier, CostBreakdown } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateFullDesignProposal(config: StallConfig): Promise<DesignResult> {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `You are FFDX4EXHIBITION AI, the world's most advanced exhibition design engine. 
Based on stall requirements, generate 4 design variations (Budget, Standard, Premium, Luxury).
For each variation, provide:
1. A specific, ultra-realistic 3D render prompt. High focus on materials (wood, glass, metal), lighting (volumetric, studio), and architectural language.
2. A detailed cost breakdown (USD) based on international standards, industry complexity, and size (${config.width}x${config.depth}x${config.height}m).
3. A narrative description.

Also provide:
- A 2D layout blueprint description with exact measurements and zone divisions.
- A comprehensive material and construction plan.
- At least 5 specific functional zones.

Your response MUST be in JSON format matching the defined schema.`;

  const userPrompt = `
Generate proposal for:
Brand: ${config.brandName || "Premium Brand"}
Industry: ${config.industry}
Location: ${config.city}, ${config.country}
Dimensions: ${config.width}m x ${config.depth}m x ${config.height}m (${config.floorType})
Theme: ${config.theme}
Elements: ${config.requiredElements.join(", ")}
Base Color Theme: ${config.colorTheme || "Professional Designer Choice"}
`;

  const response = await ai.models.generateContent({
    model,
    contents: userPrompt,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          variations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                tier: { type: Type.STRING, enum: ["Budget", "Standard", "Premium", "Luxury"] },
                prompt: { type: Type.STRING },
                description: { type: Type.STRING },
                cost: {
                  type: Type.OBJECT,
                  properties: {
                    baseConstruction: { type: Type.NUMBER },
                    materials: { type: Type.NUMBER },
                    lighting: { type: Type.NUMBER },
                    setup: { type: Type.NUMBER },
                    transport: { type: Type.NUMBER },
                    total: { type: Type.NUMBER }
                  },
                  required: ["baseConstruction", "materials", "lighting", "setup", "transport", "total"]
                }
              },
              required: ["tier", "prompt", "description", "cost"]
            }
          },
          layoutBlueprint: { type: Type.STRING },
          materialPlan: { type: Type.STRING },
          zones: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                zone: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ["zone", "description"]
            }
          },
          promptBase: { type: Type.STRING }
        },
        required: ["variations", "layoutBlueprint", "materialPlan", "zones", "promptBase"]
      }
    }
  });

  const parsed = JSON.parse(response.text || "{}");
  
  // Generating images for each tier
  const variationsWithImages = await Promise.all(parsed.variations.map(async (v: any) => {
    const imageUrl = await generateStallImage(v.prompt);
    return {
      tier: v.tier as BudgetTier,
      imageUrl,
      cost: v.cost as CostBreakdown,
      description: v.description
    };
  }));

  return {
    variations: variationsWithImages,
    layoutBlueprint: parsed.layoutBlueprint,
    materialPlan: parsed.materialPlan,
    zones: parsed.zones,
    promptBase: parsed.promptBase
  };
}

export async function generateStallImage(prompt: string): Promise<string> {
  const model = "gemini-2.5-flash-image";
  
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [{ text: "Ultra realistic 3D render of exhibition stall booth, " + prompt + ", professional photography, cinema lighting, 8k resolution, exhibition hall background with soft bokeh people" }]
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9",
        imageSize: "1K"
      }
    }
  });

  const part = response.candidates[0].content.parts.find(p => p.inlineData);
  if (part?.inlineData) {
    return `data:image/png;base64,${part.inlineData.data}`;
  }
  
  throw new Error("Failed to generate image");
}
