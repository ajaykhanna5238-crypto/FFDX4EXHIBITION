/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DesignForm } from './components/DesignForm';
import { ResultSection } from './components/ResultSection';
import { StallConfig, DesignResult } from './types';
import { generateFullDesignProposal } from './services/gemini';
import { Sparkles, ArrowRight, Zap, Shield, Globe, Layout, Layers, Boxes, Cpu } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<DesignResult | null>(null);

  const handleGenerate = async (config: StallConfig) => {
    setIsLoading(true);
    setResult(null);
    try {
      const designResult = await generateFullDesignProposal(config);
      setResult(designResult);
    } catch (error) {
      console.error("Design generation failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020202] text-white selection:bg-blue-500/30">
      {/* Dynamic Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-600/10 blur-[150px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-purple-600/10 blur-[150px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
        <div className="absolute top-[30%] left-[40%] w-[30%] h-[30%] bg-indigo-600/5 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Nav */}
      <nav className="relative z-10 border-b border-white/5 bg-black/40 backdrop-blur-2xl">
        <div className="max-w-7xl mx-auto px-8 h-24 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-tr from-blue-600 to-violet-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-500/30">
              <Layers className="w-7 h-7 text-white" />
            </div>
            <div>
              <span className="text-2xl font-black tracking-tighter block leading-none">FFDX4</span>
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">EXHIBITION ENGINE</span>
            </div>
          </div>
          <div className="hidden lg:flex items-center gap-10 text-[10px] font-black text-gray-500 uppercase tracking-widest">
            <a href="#" className="hover:text-blue-400 transition-all">Systems</a>
            <a href="#" className="hover:text-blue-400 transition-all border border-blue-500/30 px-3 py-1.5 rounded-lg text-blue-400">Architecture</a>
            <a href="#" className="hover:text-blue-400 transition-all">Vendors</a>
            <a href="#" className="hover:text-blue-400 transition-all">Enterprise</a>
          </div>
          <div className="flex items-center gap-4">
            <button className="hidden md:block px-6 py-3 bg-white/5 hover:bg-white/10 text-white rounded-2xl text-xs font-black uppercase transition-all tracking-widest border border-white/10">
              Console
            </button>
            <button className="px-6 py-3 bg-white text-black rounded-2xl text-xs font-black uppercase transition-all shadow-xl hover:scale-105 active:scale-95">
              Launch Engine
            </button>
          </div>
        </div>
      </nav>

      <main className="relative z-10 max-w-7xl mx-auto px-8 pt-24">
        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div
              key="hero"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-32"
            >
              {/* Massive Hero */}
              <div className="text-center max-w-5xl mx-auto space-y-10">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="inline-flex items-center gap-3 px-4 py-2 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-full text-[10px] font-black uppercase tracking-[0.2em] text-blue-400"
                >
                  <Cpu className="w-4 h-4" />
                  <span>Evolutionary AI Architecture</span>
                </motion.div>
                <h1 className="text-7xl md:text-8xl font-black tracking-tighter leading-[0.9] text-white">
                  The architecture of <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-600">Pure Presence.</span>
                </h1>
                <p className="text-2xl text-gray-400 max-w-3xl mx-auto font-medium leading-relaxed">
                  Automate your exhibition strategy. Instant 3D realism, dynamic costing, and technical blueprints for global pavilions.
                </p>
              </div>

              {/* Advanced Form */}
              <DesignForm onGenerate={handleGenerate} isLoading={isLoading} />

              {/* Core Systems Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-12 bg-white/[0.02] backdrop-blur-2xl rounded-[40px] p-16 border border-white/5 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-10 opacity-10">
                  <Boxes className="w-64 h-64 text-blue-500" />
                </div>
                <div className="space-y-6 relative z-10">
                  <div className="w-16 h-16 bg-blue-600/20 rounded-3xl flex items-center justify-center">
                    <Globe className="w-8 h-8 text-blue-400" />
                  </div>
                  <h3 className="text-2xl font-black tracking-tight">Global Protocol</h3>
                  <p className="text-gray-400 leading-relaxed font-medium">Auto-populates designs based on country-specific fire safety and expo standards.</p>
                </div>
                <div className="space-y-6 relative z-10">
                  <div className="w-16 h-16 bg-purple-600/20 rounded-3xl flex items-center justify-center">
                    <Layout className="w-8 h-8 text-purple-400" />
                  </div>
                  <h3 className="text-2xl font-black tracking-tight">Zone Matrix</h3>
                  <p className="text-gray-400 leading-relaxed font-medium">Heuristic traffic flow mapping for reception, interaction, and conversion zones.</p>
                </div>
                <div className="space-y-6 relative z-10">
                  <div className="w-16 h-16 bg-emerald-600/20 rounded-3xl flex items-center justify-center">
                    <Shield className="w-8 h-8 text-emerald-400" />
                  </div>
                  <h3 className="text-2xl font-black tracking-tight">Full Execution</h3>
                  <p className="text-gray-400 leading-relaxed font-medium">BOM (Bill of Materials) generation ready for global vendor marketplaces.</p>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="result"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-16"
            >
              <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-10">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 bg-green-500/10 text-green-400 text-[10px] font-black uppercase rounded-full border border-green-500/20">System Success</span>
                    <span className="text-gray-600 font-mono text-[10px]">VER: 4.8.2-FFDX</span>
                  </div>
                  <h2 className="text-6xl font-black tracking-tighter leading-none">Architectural Proposal</h2>
                  <p className="text-xl text-gray-400 max-w-2xl font-medium italic">"Every detail engineered for market dominance."</p>
                </div>
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setResult(null)}
                    className="px-8 py-4 bg-white/5 hover:bg-white/10 rounded-2xl font-black text-xs uppercase tracking-widest transition-all border border-white/5"
                  >
                    Reset Engine
                  </button>
                  <button className="flex items-center gap-3 px-8 py-4 bg-blue-600 hover:bg-blue-500 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-2xl shadow-blue-600/20">
                    Export Master Report
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <ResultSection result={result} onReset={() => setResult(null)} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Advanced Footer */}
      <footer className="border-t border-white/5 py-24 mt-40 bg-black/60 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-8 grid grid-cols-1 md:grid-cols-4 gap-16">
          <div className="col-span-2 space-y-8">
             <div className="flex items-center gap-3">
                <Layers className="w-8 h-8 text-blue-500" />
                <span className="text-3xl font-black tracking-tighter">FFDX4</span>
             </div>
             <p className="text-gray-500 max-w-sm text-sm font-medium">The definitive platform for exhibition automation. FFDX4 Exhibition leverages advanced neural architectures to transform requirements into structural reality.</p>
          </div>
          <div className="space-y-6">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-white">System</h4>
            <div className="flex flex-col gap-3 text-sm text-gray-500 font-medium font-mono">
              <a href="#" className="hover:text-white transition-colors">PROMPT_ENGINE</a>
              <a href="#" className="hover:text-white transition-colors">COST_STRATEGY</a>
              <a href="#" className="hover:text-white transition-colors">LAYOUT_MATRIX</a>
            </div>
          </div>
          <div className="space-y-6">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-white">Contact</h4>
            <div className="flex flex-col gap-3 text-sm text-gray-500 font-medium">
              <span className="font-mono">CORE@FFDX.GLOBAL</span>
              <span>+1 (GLOBAL) 800-FFDX</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
