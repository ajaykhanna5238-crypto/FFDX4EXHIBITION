import React from 'react';
import { DesignResult, DesignVariation } from '../types';
import { motion } from 'motion/react';
import { Download, Copy, Share2, Map, Layout, Sparkles, Wand2, DollarSign, Construction, Ruler, ChevronRight, FileText } from 'lucide-react';
import { cn } from '../lib/utils';

interface ResultSectionProps {
  result: DesignResult;
  onReset: () => void;
}

export function ResultSection({ result, onReset }: ResultSectionProps) {
  const [selectedVariation, setSelectedVariation] = React.useState<DesignVariation>(
    result.variations.find(v => v.tier === 'Premium') || result.variations[0]
  );

  const copyPrompt = (prompt: string) => {
    navigator.clipboard.writeText(prompt);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  return (
    <div className="space-y-16 pb-32">
      {/* Variation Selection & Hero */}
      <section className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <Sparkles className="w-5 h-5 text-purple-400" />
            </div>
            <h3 className="text-2xl font-bold text-white">Visual Prototypes</h3>
          </div>
          
          <div className="flex bg-white/5 p-1.5 rounded-2xl border border-white/10">
            {result.variations.map((v) => (
              <button
                key={v.tier}
                onClick={() => setSelectedVariation(v)}
                className={cn(
                  "px-6 py-2.5 rounded-xl text-sm font-bold transition-all",
                  selectedVariation.tier === v.tier
                    ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30"
                    : "text-gray-400 hover:text-white"
                )}
              >
                {v.tier}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Visual */}
          <div className="lg:col-span-8 space-y-6">
            <motion.div
              key={selectedVariation.tier}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative aspect-[16/9] rounded-3xl overflow-hidden border border-white/10 shadow-2xl group bg-gray-900"
            >
              <img 
                src={selectedVariation.imageUrl} 
                alt={`${selectedVariation.tier} Stall Design`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-8 left-8 space-y-2">
                <span className="px-3 py-1 bg-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest text-white ring-4 ring-blue-600/20">
                  {selectedVariation.tier} EDITION
                </span>
                <p className="text-white text-lg font-medium opacity-90">{selectedVariation.description}</p>
              </div>
            </motion.div>

            <div className="grid grid-cols-4 gap-4">
              {result.variations.map(v => (
                <button
                  key={v.tier}
                  onClick={() => setSelectedVariation(v)}
                  className={cn(
                    "aspect-square rounded-2xl overflow-hidden border-2 transition-all relative group",
                    selectedVariation.tier === v.tier ? "border-blue-500 scale-[1.02]" : "border-transparent opacity-50 grayscale hover:grayscale-0 hover:opacity-100"
                  )}
                >
                  <img src={v.imageUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-[10px] font-bold text-white uppercase">{v.tier}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Cost Engine Panel */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white/[0.03] backdrop-blur-xl rounded-3xl p-8 border border-white/10 space-y-8 shadow-2xl">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-400" />
                <h4 className="font-bold text-white uppercase tracking-widest text-xs">Cost Estimation Engine</h4>
              </div>

              <div className="space-y-4">
                {[
                  { label: "Base Construction", value: selectedVariation.cost.baseConstruction },
                  { label: "Material Sourcing", value: selectedVariation.cost.materials },
                  { label: "Design & AV", value: selectedVariation.cost.lighting },
                  { label: "Booth Setup", value: selectedVariation.cost.setup },
                  { label: "Logistics", value: selectedVariation.cost.transport },
                ].map((item, idx) => (
                  <div key={idx} className="flex justify-between items-center text-sm">
                    <span className="text-gray-500">{item.label}</span>
                    <span className="text-white font-mono">{formatCurrency(item.value)}</span>
                  </div>
                ))}
              </div>

              <div className="h-px bg-white/10" />

              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 font-bold uppercase text-[10px]">Total Estimated Cost</span>
                  <span className="text-2xl font-black text-emerald-400 font-mono">
                    {formatCurrency(selectedVariation.cost.total)}
                  </span>
                </div>
                <p className="text-[10px] text-gray-500 italic">*Excluding tax & venue utility charges.</p>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4">
                <button className="flex flex-col items-center gap-2 p-4 bg-white/5 rounded-2xl hover:bg-white/10 transition-all border border-white/5">
                  <Download className="w-5 h-5 text-gray-400" />
                  <span className="text-[10px] font-bold uppercase text-gray-400">Excel</span>
                </button>
                <button className="flex flex-col items-center gap-2 p-4 bg-blue-600 rounded-2xl hover:bg-blue-500 transition-all shadow-lg shadow-blue-600/20">
                  <FileText className="w-5 h-5 text-white" />
                  <span className="text-[10px] font-bold uppercase text-white">Full Report</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Data & Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Layout & Zones */}
        <section className="lg:col-span-8 space-y-8">
          <div className="bg-white/[0.03] backdrop-blur-xl rounded-3xl p-8 border border-white/10 space-y-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 rounded-lg">
                  <Ruler className="w-5 h-5 text-blue-400" />
                </div>
                <h3 className="text-xl font-bold text-white">2D Blueprint & Layout</h3>
              </div>
              <button className="text-xs font-bold text-blue-400 flex items-center gap-1 hover:underline">
                OPEN CAD VIEWER <ChevronRight className="w-3 h-3" />
              </button>
            </div>
            
            <p className="text-gray-300 leading-relaxed font-mono text-sm border-l-2 border-blue-500/30 pl-6 py-2">
              {result.layoutBlueprint}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {result.zones.map((zone, idx) => (
                <div key={idx} className="p-5 bg-black/40 rounded-2xl border border-white/5 space-y-2 group hover:border-blue-500/30 transition-all">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-500" />
                    <span className="text-xs font-black text-white uppercase tracking-widest">{zone.zone}</span>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed">{zone.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white/[0.03] backdrop-blur-xl rounded-3xl p-8 border border-white/10 space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-500/20 rounded-lg">
                <Construction className="w-5 h-5 text-orange-400" />
              </div>
              <h3 className="text-xl font-bold text-white">Material & Construction Plan</h3>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">
              {result.materialPlan}
            </p>
          </div>
        </section>

        {/* AI & Sharing */}
        <section className="lg:col-span-4 space-y-8">
          <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-3xl p-8 relative overflow-hidden group">
            <div className="relative z-10 space-y-4">
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                <Wand2 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-black text-white leading-tight">Master Prompt Engine</h3>
              <p className="text-indigo-100 text-xs italic opacity-80 line-clamp-3 group-hover:line-clamp-none transition-all">
                "{result.promptBase}"
              </p>
              <button
                onClick={() => copyPrompt(result.promptBase)}
                className="w-full flex items-center justify-center gap-2 py-3 bg-white text-indigo-900 rounded-2xl font-black text-xs uppercase tracking-tighter hover:bg-indigo-50 transition-all"
              >
                <Copy className="w-4 h-4" />
                Copy Master Prompt
              </button>
            </div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16" />
          </div>

          <div className="bg-white/5 rounded-3xl p-8 border border-white/10 space-y-6">
            <h4 className="text-xs font-black text-gray-500 uppercase tracking-widest">Share with Team</h4>
            <div className="flex gap-4">
              <button className="flex-1 p-3 bg-white/5 rounded-xl text-white hover:bg-white/10 transition-all flex items-center justify-center gap-2">
                <Share2 className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-tighter">Share Link</span>
              </button>
            </div>
            <p className="text-[10px] text-gray-500 text-center uppercase tracking-widest font-black">Powered by FFDX AI Cloud</p>
          </div>
        </section>
      </div>
    </div>
  );
}
