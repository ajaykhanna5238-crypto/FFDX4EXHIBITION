import React, { useState } from 'react';
import { StallConfig, Industry, BudgetTier, FloorType, Theme } from '../types';
import { cn } from '../lib/utils';
import { Layout, Palette, Box, Layers, DollarSign, Briefcase, Sparkles, Globe, MapPin, Ruler, Scaling, Construction } from 'lucide-react';
import { motion } from 'motion/react';

interface DesignFormProps {
  onGenerate: (config: StallConfig) => void;
  isLoading: boolean;
}

const industries: Industry[] = ['Tech', 'Fashion', 'Food', 'Automotive', 'Jewellery', 'Perfume', 'Healthcare', 'Other'];
const budgetTiers: BudgetTier[] = ['Budget', 'Standard', 'Premium', 'Luxury'];
const floorTypes: FloorType[] = ['Ground', 'Multi-level'];
const themes: Theme[] = ['Modern', 'Luxury', 'Futuristic', 'Cultural', 'Minimal', 'Industrial'];
const availableElements = ["LED Wall", "Reception Desk", "Storage Room", "Meeting Area", "Product Display", "Lounge", "Bar / Cafe", "Hanging Banner"];

export function DesignForm({ onGenerate, isLoading }: DesignFormProps) {
  const [config, setConfig] = useState<StallConfig>({
    width: 6,
    depth: 4,
    height: 3,
    floorType: 'Ground',
    industry: 'Tech',
    budget: 'Standard',
    country: 'USA',
    city: 'Las Vegas',
    theme: 'Modern',
    requiredElements: ["Reception Desk", "Product Display"],
    brandName: '',
    colorTheme: ''
  });

  const toggleElement = (element: string) => {
    setConfig(prev => ({
      ...prev,
      requiredElements: prev.requiredElements.includes(element)
        ? prev.requiredElements.filter(e => e !== element)
        : [...prev.requiredElements, element]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(config);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto bg-white/[0.03] backdrop-blur-xl rounded-3xl p-8 border border-white/10 shadow-2xl"
    >
      <div className="flex items-center gap-3 mb-10">
        <div className="p-3 bg-blue-500/20 rounded-2xl shadow-inner shadow-blue-500/20">
          <Construction className="w-6 h-6 text-blue-400" />
        </div>
        <div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">Design Engine</h2>
          <p className="text-gray-400 text-sm">Input your exhibition parameters for AI generation</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Brand & Location */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Layers className="w-3 h-3" /> Brand Name
            </label>
            <input
              type="text"
              placeholder="e.g. FFDX Global"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
              value={config.brandName}
              onChange={e => setConfig(prev => ({ ...prev, brandName: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Globe className="w-3 h-3" /> Country
            </label>
            <input
              type="text"
              placeholder="e.g. Germany"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
              value={config.country}
              onChange={e => setConfig(prev => ({ ...prev, country: e.target.value }))}
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <MapPin className="w-3 h-3" /> City
            </label>
            <input
              type="text"
              placeholder="e.g. Berlin"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
              value={config.city}
              onChange={e => setConfig(prev => ({ ...prev, city: e.target.value }))}
              required
            />
          </div>
        </div>

        {/* Dimensions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Ruler className="w-3 h-3" /> Width (m)
            </label>
            <input
              type="number"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
              value={config.width}
              onChange={e => setConfig(prev => ({ ...prev, width: Number(e.target.value) }))}
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Scaling className="w-3 h-3" /> Depth (m)
            </label>
            <input
              type="number"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
              value={config.depth}
              onChange={e => setConfig(prev => ({ ...prev, depth: Number(e.target.value) }))}
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Scaling className="w-3 h-3" /> Height (m)
            </label>
            <input
              type="number"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
              value={config.height}
              onChange={e => setConfig(prev => ({ ...prev, height: Number(e.target.value) }))}
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Layout className="w-3 h-3" /> Level
            </label>
            <select
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-medium"
              value={config.floorType}
              onChange={e => setConfig(prev => ({ ...prev, floorType: e.target.value as FloorType }))}
            >
              {floorTypes.map(f => (
                <option key={f} value={f} className="bg-gray-900">{f}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Industry & Theme */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Briefcase className="w-3 h-3" /> Industry
            </label>
            <select
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white appearance-none transition-all font-medium"
              value={config.industry}
              onChange={e => setConfig(prev => ({ ...prev, industry: e.target.value as Industry }))}
            >
              {industries.map(i => (
                <option key={i} value={i} className="bg-gray-900">{i}</option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Palette className="w-3 h-3" /> Theme
            </label>
            <select
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white appearance-none transition-all font-medium"
              value={config.theme}
              onChange={e => setConfig(prev => ({ ...prev, theme: e.target.value as Theme }))}
            >
              {themes.map(t => (
                <option key={t} value={t} className="bg-gray-900">{t}</option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
              <Palette className="w-3 h-3" /> Colors
            </label>
            <input
              type="text"
              placeholder="e.g. Electric Blue, Silver"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white font-medium"
              value={config.colorTheme}
              onChange={e => setConfig(prev => ({ ...prev, colorTheme: e.target.value }))}
            />
          </div>
        </div>

        {/* Required Elements */}
        <div className="space-y-4">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
            <Box className="w-3 h-3" /> Booth Elements
          </label>
          <div className="flex flex-wrap gap-2">
            {availableElements.map(el => (
              <button
                key={el}
                type="button"
                onClick={() => toggleElement(el)}
                className={cn(
                  "px-4 py-2 rounded-full text-xs font-bold transition-all border",
                  config.requiredElements.includes(el)
                    ? "bg-blue-600 border-blue-400 text-white shadow-lg shadow-blue-600/30"
                    : "bg-white/5 border-white/10 text-gray-400 hover:border-white/30"
                )}
              >
                {el}
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className={cn(
            "w-full py-5 rounded-2xl font-black text-xl transition-all flex items-center justify-center gap-3 overflow-hidden relative group",
            isLoading 
              ? "bg-gray-800 text-gray-500 cursor-not-allowed" 
              : "bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white shadow-2xl shadow-blue-500/20"
          )}
        >
          {isLoading ? (
            <>
              <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin" />
              Processing Advanced Architect Engine...
            </>
          ) : (
            <>
              <Sparkles className="w-6 h-6 animate-pulse" />
              GENERATE FULL STALL PROPOSAL
              <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            </>
          )}
        </button>
      </form>
    </motion.div>
  );
}
