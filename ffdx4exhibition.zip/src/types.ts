export type StallSize = string;
export type OpenSides = 1 | 2 | 3 | 4;
export type Industry = 'Tech' | 'Fashion' | 'Food' | 'Automotive' | 'Jewellery' | 'Perfume' | 'Healthcare' | 'Other';
export type BudgetTier = 'Budget' | 'Standard' | 'Premium' | 'Luxury';
export type FloorType = 'Ground' | 'Multi-level';
export type Theme = 'Modern' | 'Luxury' | 'Futuristic' | 'Cultural' | 'Minimal' | 'Industrial';

export interface StallConfig {
  width: number;
  depth: number;
  height: number;
  floorType: FloorType;
  industry: Industry;
  budget: BudgetTier;
  country: string;
  city: string;
  theme: Theme;
  requiredElements: string[]; // e.g. ["LED Wall", "Reception Desk", "Storage Room"]
  brandName?: string;
  colorTheme?: string;
}

export interface CostBreakdown {
  baseConstruction: number;
  materials: number;
  lighting: number;
  setup: number;
  transport: number;
  total: number;
}

export interface DesignVariation {
  tier: BudgetTier;
  imageUrl: string;
  cost: CostBreakdown;
  description: string;
}

export interface DesignResult {
  variations: DesignVariation[];
  layoutBlueprint: string;
  materialPlan: string;
  zones: { zone: string; description: string }[];
  promptBase: string;
}
